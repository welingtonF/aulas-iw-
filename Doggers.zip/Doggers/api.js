//Preencher automático
function criaLinha(doce) {
    document.getElementById("id").value = doce.id;
    document.getElementById("cname").value = doce.cname;
    document.getElementById("tipo").value = doce.tipo;
    
  }
  
  function doGet() {
    return "GET";
  }
  
  function doPost() {
    return "POST";
  }
  
  function doPut() {
    return "PUT";
  }
  
  function doDelete() {
    return "DELETE";
  }
  
  function doFindById() {
    let n = document.getElementById("id").value;
    return n;
  }
  
  async function clienteDados(minhaFuncao) {
    let n = doFindById();
  
    const url = `https://localhost:3000/candy/${n}`;
    const urls = `https://localhost:3000/candy`;
  
    console.log(n);
  
    let rest;
  
    rest = minhaFuncao;
  
    let id = document.getElementById("id").value;
    let nome = document.getElementById("cname").value;
    let tipo = document.getElementById("tipo").value;
    
  
    const object = { id, nome, tipo };
  
    const myInitGet = {
      method: rest,
      headers: {
        "Content-Type": "application/json",
      },
    };
  
    const myInitPost = {
      method: rest,
      body: JSON.stringify(object),
      headers: {
        "Content-Type": "application/json",
      },
    };
  
    if (rest === "GET") {
      const dados = await fetch(url, myInitGet);
      const elens = await dados.json();
      criaLinha(elens);
    } else if (rest === "POST") {
      const dados = await fetch(url, myInitPost);
      const elens = await dados.json();
      criaLinha(elens);
    } else if (rest === "DELETE") {
      const dados = await fetch(urls, myInitPost);
      const elens = await dados.json();
      criaLinha(elens);
    } else {
      const dados = await fetch(urls, myInitPost);
      const elens = await dados.json();
      criaLinha(elens);
    }
  }
  